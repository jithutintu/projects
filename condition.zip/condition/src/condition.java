import java.util.Scanner;
class condition
{
public static void main(String args[])
{
int i;
Scanner obj=new Scanner(System.in);
System.out.println("enter the n valuee.....");
i=obj.nextInt();
for(i=0;i<=5;i++)
{
System.out.println("The values are"+i);
}
}
}